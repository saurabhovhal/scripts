# Linux Server Automation Framework

Shell-based server monitoring & automation framework for production Linux fleets.

## Status: Phase 1 (Foundation) complete

- `config/config.conf` — all thresholds, paths, and settings (nothing hardcoded in scripts)
- `lib/common.sh` — bootstrap: loads config + all other lib files
- `lib/logging.sh` — timestamped INFO/WARN/ERROR/CRIT logging to `/var/log/server-automation/`
- `lib/validation.sh` — input/environment validation helpers (`require_cmd`, `require_file`, `require_root`, threshold comparison)
- `lib/notification.sh` — alerting via email / webhook / log (toggle in config.conf)
- `bin/server_health.sh` — server health monitor (CPU, memory, swap, disk, load, processes, zombies, uptime, network)

## Setup

```bash
git clone <repo> linux-server-automation
cd linux-server-automation
chmod +x bin/*.sh lib/*.sh
```

No external dependencies beyond standard coreutils, `awk`, `ps`, `df`, `free`, `ping`.
Optional: `mail` (email alerts), `curl` (webhook alerts), `bc` (float threshold math).

If `/var/log/server-automation` isn't writable by the running user, scripts
fall back to a local `logs/` directory automatically.

## Running the health check

```bash
./bin/server_health.sh              # human-readable report
./bin/server_health.sh --json       # machine-readable, for dashboards/cron
./bin/server_health.sh --quiet      # suppress report, only log + alert
```

Exit codes: `0` = OK, `1` = WARNING, `2` = CRITICAL, `3` = script error.
These are designed to be checked directly in cron (`0/5 * * * * bin/server_health.sh --quiet || alert_something`).

## Configuration

Edit `config/config.conf` to change thresholds:

```
CPU_THRESHOLD_WARN=70
CPU_THRESHOLD_CRIT=85
MEM_THRESHOLD_WARN=80
...
```

Enable alerting by setting `ENABLE_EMAIL_ALERTS=true` and/or
`ENABLE_WEBHOOK_ALERTS=true` and filling in `ALERT_EMAIL` / `ALERT_WEBHOOK_URL`.

## Design notes

- Scripts use `set -uo pipefail` but deliberately **not** `-e` in the health
  checker: a single failed metric collection (e.g. `free` missing on a
  minimal container image) shouldn't abort the whole health report. Scripts
  that perform destructive or stateful actions (backup, cleanup, user mgmt)
  use full strict mode (`set -Eeuo pipefail`) with `trap ... EXIT` cleanup,
  since a partial failure there is dangerous to ignore.
- Float comparisons (load average, thresholds) use `awk`/`bc` since Bash's
  `(( ))` only supports integers.
- All scripts source `lib/common.sh`, which resolves paths relative to the
  script's own location — so the framework runs correctly regardless of the
  caller's working directory.

## Roadmap (per client brief)

- [x] Phase 1 — Foundation, config, libs, server_health.sh
- [ ] Phase 2 — log_analyzer.sh, log_monitor.sh, log rotation/archival
- [ ] Phase 3 — process_monitor.sh, systemd service, restart automation
- [ ] Phase 4 — disk_cleanup.sh, backup.sh
- [ ] Phase 5 — remote_health_check.sh, parallel SSH, network/app health
- [ ] Phase 6 — security/user audit, user management
- [ ] Phase 7 — cron scheduling, error handling hardening, centralized logs
- [ ] Phase 8 — incident simulator, tests, docs, architecture diagram
