#!/usr/bin/env bash
# ============================================================
# validation.sh - Input & environment validation helpers
# ============================================================

if [[ -n "${_VALIDATION_SH_LOADED:-}" ]]; then
    return 0 2>/dev/null || exit 0
fi
_VALIDATION_SH_LOADED=1

# require_cmd <cmd> [cmd2 ...] - exit if any required command is missing
require_cmd() {
    local missing=()
    for c in "$@"; do
        command -v "$c" >/dev/null 2>&1 || missing+=("$c")
    done
    if (( ${#missing[@]} > 0 )); then
        echo "ERROR: missing required commands: ${missing[*]}" >&2
        exit 127
    fi
}

# is_number <value> - true if value is an integer or float
is_number() {
    [[ "$1" =~ ^[0-9]+([.][0-9]+)?$ ]]
}

# require_file <path> - exit if file doesn't exist / isn't readable
require_file() {
    local f="$1"
    if [[ ! -r "$f" ]]; then
        echo "ERROR: required file not found or not readable: $f" >&2
        exit 1
    fi
}

# require_root - exit if not running as root
require_root() {
    if [[ "$(id -u)" -ne 0 ]]; then
        echo "ERROR: this operation requires root privileges" >&2
        exit 1
    fi
}

# validate_threshold_crossed <value> <warn> <crit> -> echoes OK|WARNING|CRITICAL
validate_threshold_crossed() {
    local value="$1" warn="$2" crit="$3"
    if (( $(echo "$value >= $crit" | bc -l 2>/dev/null || echo 0) )); then
        echo "CRITICAL"
    elif (( $(echo "$value >= $warn" | bc -l 2>/dev/null || echo 0) )); then
        echo "WARNING"
    else
        echo "OK"
    fi
}
