#!/usr/bin/env bash
# ============================================================
# logging.sh - Centralized logging library
# Usage: source this file, then call log_info / log_warn / log_error
# ============================================================

# Guard against double-sourcing
if [[ -n "${_LOGGING_SH_LOADED:-}" ]]; then
    return 0 2>/dev/null || exit 0
fi
_LOGGING_SH_LOADED=1

_LOG_SCRIPT_NAME="$(basename "${0:-script}")"
_LOG_FILE="${LOG_DIR:-/var/log/server-automation}/${_LOG_SCRIPT_NAME%.sh}.log"

_ensure_log_dir() {
    local dir
    dir="$(dirname "$_LOG_FILE")"
    if [[ ! -d "$dir" ]]; then
        mkdir -p "$dir" 2>/dev/null || {
            # Fall back to a local logs/ dir if we can't write to /var/log
            _LOG_FILE="$(pwd)/logs/${_LOG_SCRIPT_NAME%.sh}.log"
            mkdir -p "$(dirname "$_LOG_FILE")"
        }
    fi
}
_ensure_log_dir

_log() {
    local level="$1"; shift
    local msg="$*"
    local ts
    ts="$(date '+%Y-%m-%d %H:%M:%S')"
    local line="${ts} ${level} ${msg}"
    echo "$line" | tee -a "$_LOG_FILE" >/dev/null
    # Also echo WARN/ERROR to stderr so they're visible interactively
    if [[ "$level" == "ERROR" || "$level" == "WARN" ]]; then
        echo "$line" >&2
    else
        echo "$line"
    fi
}

log_info()  { _log "INFO"  "$@"; }
log_warn()  { _log "WARN"  "$@"; }
log_error() { _log "ERROR" "$@"; }
log_crit()  { _log "CRIT"  "$@"; }
