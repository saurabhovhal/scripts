#!/usr/bin/env bash
# ============================================================
# common.sh - Bootstrap: locates project root, loads config
#              and all other lib/*.sh files.
# Every bin/*.sh script should start with:
#   SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
#   source "$SCRIPT_DIR/../lib/common.sh"
# ============================================================

if [[ -n "${_COMMON_SH_LOADED:-}" ]]; then
    return 0 2>/dev/null || exit 0
fi
_COMMON_SH_LOADED=1

# Resolve project root relative to this file (lib/common.sh -> project root)
LIB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$LIB_DIR/.." && pwd)"

# Load configuration (allow override via SERVER_AUTOMATION_CONFIG env var)
CONFIG_FILE="${SERVER_AUTOMATION_CONFIG:-$PROJECT_ROOT/config/config.conf}"
if [[ -f "$CONFIG_FILE" ]]; then
    # shellcheck disable=SC1090
    source "$CONFIG_FILE"
else
    echo "ERROR: config file not found at $CONFIG_FILE" >&2
    exit 1
fi

# shellcheck disable=SC1091
source "$LIB_DIR/logging.sh"
# shellcheck disable=SC1091
source "$LIB_DIR/validation.sh"
# shellcheck disable=SC1091
source "$LIB_DIR/notification.sh"

# Standard strict-mode helper. Call `enable_strict_mode` at the top of a
# script's main logic (not always at the very top of the file — see README
# "Error Handling" section for why: strict mode + `local var=$(cmd)` can
# mask a failing $(cmd) if not handled, and sourced files with unset vars
# under `set -u` can abort a script prematurely if they aren't defensive).
enable_strict_mode() {
    set -Eeuo pipefail
}

# cleanup_and_exit is meant to be registered with `trap`, e.g.:
#   trap 'cleanup_and_exit $?' EXIT
cleanup_and_exit() {
    local exit_code="${1:-0}"
    if [[ $exit_code -ne 0 ]]; then
        log_error "Script exited with code $exit_code"
    fi
    exit "$exit_code"
}
