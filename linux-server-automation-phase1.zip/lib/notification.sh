#!/usr/bin/env bash
# ============================================================
# notification.sh - Alerting via email / webhook / log
# ============================================================

if [[ -n "${_NOTIFICATION_SH_LOADED:-}" ]]; then
    return 0 2>/dev/null || exit 0
fi
_NOTIFICATION_SH_LOADED=1

# send_alert <severity> <subject> <message>
send_alert() {
    local severity="$1" subject="$2" message="$3"

    # Always log the alert
    if command -v log_crit >/dev/null 2>&1; then
        case "$severity" in
            CRITICAL) log_crit "ALERT: $subject - $message" ;;
            WARNING)  log_warn "ALERT: $subject - $message" ;;
            *)        log_info "ALERT: $subject - $message" ;;
        esac
    else
        echo "[$severity] $subject - $message"
    fi

    # Email
    if [[ "${ENABLE_EMAIL_ALERTS:-false}" == "true" && -n "${ALERT_EMAIL:-}" ]]; then
        if command -v mail >/dev/null 2>&1; then
            echo "$message" | mail -s "[$severity] $subject" "$ALERT_EMAIL" \
                || echo "WARN: failed to send email alert" >&2
        else
            echo "WARN: 'mail' command not available, skipping email alert" >&2
        fi
    fi

    # Webhook
    if [[ "${ENABLE_WEBHOOK_ALERTS:-false}" == "true" && -n "${ALERT_WEBHOOK_URL:-}" ]]; then
        if command -v curl >/dev/null 2>&1; then
            curl -s -X POST -H 'Content-Type: application/json' \
                -d "{\"severity\":\"$severity\",\"subject\":\"$subject\",\"message\":\"$message\"}" \
                "$ALERT_WEBHOOK_URL" >/dev/null \
                || echo "WARN: failed to send webhook alert" >&2
        else
            echo "WARN: 'curl' not available, skipping webhook alert" >&2
        fi
    fi
}
