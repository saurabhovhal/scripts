#!/usr/bin/env bash
###############################################################################
# run_all_tests.sh - Runs every test_*.sh in this directory
###############################################################################
set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

TOTAL_SUITES=0
FAILED_SUITES=0

for test_file in "${SCRIPT_DIR}"/test_*.sh; do
    [[ -f "$test_file" ]] || continue
    TOTAL_SUITES=$((TOTAL_SUITES+1))
    echo ""
    echo "############################################################"
    echo "# Running: $(basename "$test_file")"
    echo "############################################################"
    if bash "$test_file"; then
        echo ">>> $(basename "$test_file"): PASSED"
    else
        echo ">>> $(basename "$test_file"): FAILED"
        FAILED_SUITES=$((FAILED_SUITES+1))
    fi
done

echo ""
echo "============================================================"
echo "Test suites run: ${TOTAL_SUITES}, failed: ${FAILED_SUITES}"
echo "============================================================"

[[ "$FAILED_SUITES" -eq 0 ]] && exit 0 || exit 1
