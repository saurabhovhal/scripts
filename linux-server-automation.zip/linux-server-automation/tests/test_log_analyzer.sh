#!/usr/bin/env bash
###############################################################################
# test_log_analyzer.sh - Integration test for bin/log_analyzer.sh
#
# Generates a synthetic log with known counts of each pattern, runs
# log_analyzer.sh against it, and verifies the reported counts match.
###############################################################################
set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

TMP_LOG="$(mktemp)"
trap 'rm -f "$TMP_LOG"' EXIT

{
    for i in 1 2 3; do echo "2026-09-16 10:00:0${i} ERROR HTTP 500 something broke"; done
    for i in 1 2; do echo "2026-09-16 10:01:0${i} ERROR connection Timeout while calling downstream"; done
    echo "2026-09-16 10:02:00 ERROR HTTP 404 not found /favicon.ico"
    echo "2026-09-16 10:03:00 ERROR Authentication failed for user bob"
    echo "2026-09-16 10:04:00 ERROR java.lang.NullPointerException at Foo.java:12"
    echo "2026-09-16 10:05:00 WARNING disk usage high"
    echo "2026-09-16 10:06:00 INFO all good"
} > "$TMP_LOG"

OUTPUT="$("${BASE_DIR}/bin/log_analyzer.sh" "$TMP_LOG")"
STATUS=$?

PASS=0
FAIL=0

check_contains() {
    local desc="$1" pattern="$2"
    if echo "$OUTPUT" | grep -qE "$pattern"; then
        echo "  PASS: $desc"
        PASS=$((PASS+1))
    else
        echo "  FAIL: $desc"
        echo "    (pattern not found: $pattern)"
        FAIL=$((FAIL+1))
    fi
}

echo "== log_analyzer.sh output checks =="
check_contains "Total Errors = 8"        "Total Errors[[:space:]]*:[[:space:]]*8"
check_contains "HTTP 500 = 3"            "HTTP 500[[:space:]]*:[[:space:]]*3"
check_contains "HTTP 404 = 1"            "HTTP 404[[:space:]]*:[[:space:]]*1"
check_contains "Timeouts = 2"            "Timeouts[[:space:]]*:[[:space:]]*2"
check_contains "Authentication = 1"      "Authentication[[:space:]]*:[[:space:]]*1"
check_contains "Unique Exceptions >= 1"  "Unique Exceptions[[:space:]]*:[[:space:]]*[1-9]"

# With errors present, exit status should be non-zero (1)
if [[ "$STATUS" -eq 1 ]]; then
    echo "  PASS: exit status is 1 when errors present"
    PASS=$((PASS+1))
else
    echo "  FAIL: exit status expected 1, got ${STATUS}"
    FAIL=$((FAIL+1))
fi

echo ""
echo "Results: ${PASS} passed, ${FAIL} failed"
[[ "$FAIL" -eq 0 ]] && exit 0 || exit 1
