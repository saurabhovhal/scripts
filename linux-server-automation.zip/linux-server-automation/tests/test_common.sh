#!/usr/bin/env bash
###############################################################################
# test_common.sh - Basic unit tests for lib/common.sh and lib/validation.sh
#
# Lightweight, dependency-free test runner (no external test framework).
# Usage: ./tests/test_common.sh
###############################################################################
set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

source "${BASE_DIR}/config/config.conf"
source "${BASE_DIR}/lib/common.sh"
source "${BASE_DIR}/lib/validation.sh"

PASS=0
FAIL=0

assert_eq() {
    local desc="$1" expected="$2" actual="$3"
    if [[ "$expected" == "$actual" ]]; then
        echo "  PASS: $desc"
        PASS=$((PASS+1))
    else
        echo "  FAIL: $desc (expected='$expected' actual='$actual')"
        FAIL=$((FAIL+1))
    fi
}

echo "== severity_from_thresholds =="
assert_eq "below warn -> OK" "OK" "$(severity_from_thresholds 50 70 90)"
assert_eq "at warn -> WARNING" "WARNING" "$(severity_from_thresholds 70 70 90)"
assert_eq "at crit -> CRITICAL" "CRITICAL" "$(severity_from_thresholds 90 70 90)"
assert_eq "above crit -> CRITICAL" "CRITICAL" "$(severity_from_thresholds 99 70 90)"

echo "== worst_status =="
assert_eq "all OK -> OK" "OK" "$(worst_status OK OK OK)"
assert_eq "one WARNING -> WARNING" "WARNING" "$(worst_status OK WARNING OK)"
assert_eq "mix with CRITICAL -> CRITICAL" "CRITICAL" "$(worst_status OK WARNING CRITICAL)"

echo "== valid_username =="
if valid_username "john"; then assert_eq "valid: john" "0" "0"; else assert_eq "valid: john" "0" "1"; fi
if valid_username "John_Doe"; then assert_eq "invalid: John_Doe rejected" "0" "1"; else assert_eq "invalid: John_Doe rejected" "0" "0"; fi
if valid_username "9user"; then assert_eq "invalid: 9user rejected" "0" "1"; else assert_eq "invalid: 9user rejected" "0" "0"; fi

echo "== valid_port =="
if valid_port "8080"; then assert_eq "valid: 8080" "0" "0"; else assert_eq "valid: 8080" "0" "1"; fi
if valid_port "70000"; then assert_eq "invalid: 70000 rejected" "0" "1"; else assert_eq "invalid: 70000 rejected" "0" "0"; fi
if valid_port "abc"; then assert_eq "invalid: abc rejected" "0" "1"; else assert_eq "invalid: abc rejected" "0" "0"; fi

echo "== is_number =="
if is_number "42"; then assert_eq "is_number 42" "0" "0"; else assert_eq "is_number 42" "0" "1"; fi
if is_number "3.14"; then assert_eq "is_number 3.14" "0" "0"; else assert_eq "is_number 3.14" "0" "1"; fi
if is_number "abc"; then assert_eq "is_number abc rejected" "0" "1"; else assert_eq "is_number abc rejected" "0" "0"; fi

echo ""
echo "Results: ${PASS} passed, ${FAIL} failed"
[[ "$FAIL" -eq 0 ]] && exit 0 || exit 1
