#!/usr/bin/env bash
###############################################################################
# test_disk_cleanup.sh - Verifies disk_cleanup.sh dry-run never deletes files
###############################################################################
set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

# Create an "old" file (mtime 30 days back) and a fresh file
OLD_FILE="${TMP_DIR}/old.log"
NEW_FILE="${TMP_DIR}/new.log"
touch "$OLD_FILE" "$NEW_FILE"
touch -d '30 days ago' "$OLD_FILE" 2>/dev/null || touch -t "$(date -d '30 days ago' +%Y%m%d0000 2>/dev/null)" "$OLD_FILE" 2>/dev/null || true

PASS=0
FAIL=0

# Default / --dry-run must not delete anything
"${BASE_DIR}/bin/disk_cleanup.sh" --dry-run --path "$TMP_DIR" --days 7 >/dev/null 2>&1

if [[ -f "$OLD_FILE" && -f "$NEW_FILE" ]]; then
    echo "  PASS: --dry-run left all files in place"
    PASS=$((PASS+1))
else
    echo "  FAIL: --dry-run deleted a file (it must never do this)"
    FAIL=$((FAIL+1))
fi

# --apply should delete the old file but keep the new one
"${BASE_DIR}/bin/disk_cleanup.sh" --apply --path "$TMP_DIR" --days 7 >/dev/null 2>&1

if [[ ! -f "$OLD_FILE" ]]; then
    echo "  PASS: --apply removed the old file"
    PASS=$((PASS+1))
else
    echo "  FAIL: --apply did not remove the old file"
    FAIL=$((FAIL+1))
fi

if [[ -f "$NEW_FILE" ]]; then
    echo "  PASS: --apply preserved the fresh file"
    PASS=$((PASS+1))
else
    echo "  FAIL: --apply incorrectly removed the fresh file"
    FAIL=$((FAIL+1))
fi

echo ""
echo "Results: ${PASS} passed, ${FAIL} failed"
[[ "$FAIL" -eq 0 ]] && exit 0 || exit 1
