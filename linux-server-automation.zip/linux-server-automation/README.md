# Linux Server Monitoring & Automation Framework

A shell-based (Bash) monitoring and automation framework for managing fleets
of Linux production servers: health monitoring, alerting, log analysis,
process/service management, backups, disk cleanup, remote/parallel server
automation, network monitoring, security auditing, and cron-driven scheduling.

## Project Structure

```
linux-server-automation/
│
├── bin/                        # Executable scripts (one job each)
│   ├── server_health.sh        # CPU/mem/swap/disk/load/zombies/uptime/network
│   ├── log_analyzer.sh         # Batch log analysis (errors, HTTP 5xx/4xx, auth failures)
│   ├── log_monitor.sh          # Real-time log tailing with alerting (tail -F)
│   ├── process_monitor.sh      # Process check + optional systemd restart
│   ├── disk_cleanup.sh         # Safe disk cleanup with --dry-run / --apply
│   ├── log_rotate.sh           # Compress + archive + retention-based deletion
│   ├── backup.sh                # App/config/log/DB backup with validation
│   ├── remote_health_check.sh  # SSH fleet health check, bounded parallelism
│   ├── network_monitor.sh      # DNS/port/HTTP/SSL/response-time checks
│   ├── app_health.sh           # App-level health (process/port/API/DB/disk/mem)
│   ├── security_audit.sh       # User/permission/SSH/SUID security audit
│   └── user_management.sh      # CSV-driven user/group create/disable/remove
│
├── lib/                        # Shared libraries, sourced by bin/ scripts
│   ├── logging.sh              # Centralized timestamped logging
│   ├── validation.sh           # Input validation helpers
│   ├── notification.sh         # Alert dispatch: log / email / webhook
│   └── common.sh               # CPU/mem/disk/load helpers, threshold logic
│
├── config/
│   ├── config.conf             # All thresholds, paths, retention — no hardcoding
│   ├── enterprise-app.service  # Sample systemd unit for the monitored app
│   ├── crontab.example         # Example cron schedule for all jobs
│   └── users_sample.csv        # Sample input for user_management.sh
│
├── reports/                    # Generated health/audit/backup reports (gitkeep)
├── logs/                       # Centralized script logs (gitkeep)
├── backups/                    # Backup output, timestamped by date (gitkeep)
├── tests/                      # Lightweight test suite (no external framework)
│   ├── test_common.sh
│   ├── test_log_analyzer.sh
│   ├── test_disk_cleanup.sh
│   └── run_all_tests.sh
├── servers/
│   └── servers.txt             # Fleet inventory for remote_health_check.sh
├── simulator/
│   └── incident_simulator.sh   # 10 safe, simulated production incidents
└── docs/
    └── TROUBLESHOOTING.md      # Production troubleshooting guide
```

## Setup

1. **Requirements**: Bash 4+, coreutils, `awk`, `sed`, `grep`, `find`, `xargs`,
   `curl`, `ssh`/`scp`, `gzip`/`tar`. Optional: `mpstat` (sysstat), `nc`,
   `dig`, `openssl`, `mail`, `pg_dump`/`mysqldump`.
2. Clone/copy this project to the target server, e.g. `/opt/linux-server-automation`.
3. Make scripts executable (already done in this delivery):
   ```bash
   chmod +x bin/*.sh lib/*.sh tests/*.sh simulator/*.sh
   ```
4. Edit `config/config.conf` — set real thresholds, paths, and toggle
   `ALERT_EMAIL_ENABLED` / `ALERT_WEBHOOK_ENABLED` as needed.
5. Edit `servers/servers.txt` with your real fleet inventory.
6. (Optional) Install the systemd unit:
   ```bash
   sudo cp config/enterprise-app.service /etc/systemd/system/
   sudo systemctl daemon-reload
   sudo systemctl enable --now enterprise-app
   ```
7. Install the cron schedule (edit `BASE_DIR` in the file first):
   ```bash
   crontab config/crontab.example
   ```

## Usage examples

```bash
# One-off health check (human-readable + JSON)
bin/server_health.sh
bin/server_health.sh --json

# Analyze an application log
bin/log_analyzer.sh /var/log/application/app.log

# Watch a log in real time for critical patterns
bin/log_monitor.sh /var/log/application/app.log &

# Check + optionally restart a process
bin/process_monitor.sh node --restart --service enterprise-app

# Disk cleanup — ALWAYS dry-run first
bin/disk_cleanup.sh --dry-run --path /var --days 14
bin/disk_cleanup.sh --apply    --path /var --days 14

# Rotate and archive a log
bin/log_rotate.sh /var/log/application/app.log

# Run a full backup
bin/backup.sh --app-dir /opt/enterprise-app --config-dir /etc/enterprise-app

# Check the whole fleet in parallel (bounded)
bin/remote_health_check.sh servers/servers.txt --parallel 10

# Network / SSL check for an endpoint
bin/network_monitor.sh example.com 443 https://example.com/health

# Application-level health check
bin/app_health.sh

# Security audit
bin/security_audit.sh --scan-path /

# Bulk user creation from CSV (dry-run first!)
bin/user_management.sh --create-from-csv config/users_sample.csv --dry-run
bin/user_management.sh --create-from-csv config/users_sample.csv
bin/user_management.sh --disable mike
bin/user_management.sh --remove mike

# Run the test suite
tests/run_all_tests.sh

# Simulate a production incident end-to-end (Detect -> Diagnose -> Remediate -> Log -> Alert)
simulator/incident_simulator.sh 3     # single incident (HTTP 500)
simulator/incident_simulator.sh all   # all 10 incidents
```

## Design notes

- **Configuration-driven**: every threshold/path lives in `config/config.conf`;
  no script hardcodes values.
- **Error handling**: scripts use `set -u` and `set -o pipefail` throughout;
  destructive scripts (`backup.sh`) additionally use `trap ... ERR` to alert
  on unexpected failure. `set -e` is intentionally **not** used globally —
  see `docs/TROUBLESHOOTING.md` for why strict mode can cause more harm than
  good in scripts that need to evaluate several independent checks and report
  a combined status rather than dying on the first non-zero exit.
- **Safety first**: `disk_cleanup.sh` and `user_management.sh` default to
  dry-run/preview behavior; destructive action requires an explicit flag.
- **Controlled parallelism**: `remote_health_check.sh` uses `xargs -P` with a
  configurable worker cap (`MAX_PARALLEL_SSH`) instead of unbounded background
  SSH sessions.
- **Centralized logging**: all scripts log to `logs/server-automation.log`
  via `lib/logging.sh`, in addition to their own stdout.
- **Alerting**: `lib/notification.sh` supports log/email/webhook, toggled
  independently in `config.conf`.

## Delivery status

This delivers all 20 items in the assigned scope: health monitoring,
threshold alerting, log analysis, real-time log monitoring, process
monitoring, systemd service management, disk cleanup, log rotation &
archival, automated backup, remote server automation, parallel execution,
network monitoring, application health checks, user & permission audit,
automated user management, cron-based automation, configuration-driven
scripting, error handling, centralized logging, and a 10-scenario incident
simulator — plus tests, a Git-ready structure, and documentation.
