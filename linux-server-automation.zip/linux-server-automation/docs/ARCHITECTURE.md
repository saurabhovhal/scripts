# Architecture & Workflow

## Component overview

```
                        +---------------------+
                        |   config/config.conf|
                        |  (thresholds, paths)|
                        +----------+----------+
                                   |
                 sourced by all   |
              +--------------------+--------------------+
              |                    |                    |
        +-----v-----+       +------v------+      +------v------+
        | lib/       |       | bin/        |      | simulator/  |
        | logging.sh |<------| *.sh        |----->| incident_   |
        | validation |       | (20 jobs)   |      | simulator.sh|
        | notification       +------+------+      +-------------+
        | common.sh  |              |
        +-----+------+              |
              |                     v
              |            +--------+--------+
              +----------->| logs/           |
                           | server-automation.log
                           +--------+--------+
                                    |
                     +--------------+--------------+
                     |                             |
              +------v------+              +-------v------+
              | reports/    |               | notification |
              | *.txt       |               | email/webhook|
              +-------------+               +--------------+
```

## Execution flow (typical monitoring job)

```
cron/systemd timer
        |
        v
  bin/<job>.sh
        |
        +--> source config/config.conf   (thresholds/paths)
        +--> source lib/logging.sh       (log_info/log_warn/...)
        +--> source lib/common.sh        (metric collection helpers)
        +--> source lib/notification.sh  (send_alert)
        |
        v
  collect metrics (CPU/mem/disk/... or log scan or SSH fleet scan)
        |
        v
  classify severity (OK / WARNING / CRITICAL) via thresholds in config.conf
        |
        v
  write report -> reports/<job>_<timestamp>.txt
  write log entries -> logs/server-automation.log
        |
        v
  if WARNING/CRITICAL -> send_alert() -> log + (optional) email + (optional) webhook
        |
        v
  exit code: 0=OK, 1=WARNING, 2=CRITICAL  (consumable by cron/monitoring systems)
```

## Incident lifecycle (used by simulator/incident_simulator.sh and in production)

```
   DETECT              DIAGNOSE             REMEDIATE            LOG & ALERT
+-----------+       +--------------+     +---------------+     +----------------+
| Monitoring|  -->  | Identify root|-->  | Apply fix     | --> | Central log +  |
| script    |       | cause via    |     | (restart svc, |     | send_alert()   |
| flags a   |       | reports/logs |     |  cleanup disk,|     | (email/webhook)|
| threshold |       | and targeted |     |  rotate log,  |     |                |
| breach    |       | commands     |     |  re-run backup|     |                |
+-----------+       +--------------+     +---------------+     +----------------+
```

## Remote fleet execution (bounded parallelism)

```
servers/servers.txt (N hosts)
        |
        v
  xargs -P <MAX_PARALLEL_SSH>   <-- caps concurrent SSH sessions
        |
        +--> ssh host1  --> collect metrics --> RAW_DIR/host1.out
        +--> ssh host2  --> collect metrics --> RAW_DIR/host2.out
        +--> ...        --> ...
        +--> ssh hostN  --> collect metrics --> RAW_DIR/hostN.out
        |
        v
  consolidate all *.out --> reports/remote_health_<timestamp>.txt
```

This avoids ever opening hundreds of simultaneous SSH connections: the
worker pool size (`MAX_PARALLEL_SSH` in `config.conf`, default 10) bounds
concurrency regardless of fleet size, and `xargs -P` reuses freed worker
slots as each host finishes.
