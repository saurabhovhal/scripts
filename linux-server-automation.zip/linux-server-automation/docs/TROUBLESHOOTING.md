# Production Troubleshooting Guide

## General approach: Detect → Diagnose → Remediate → Log → Alert

Every script in `bin/` follows this pattern. When something goes wrong in
production, use the matching script's report + `logs/server-automation.log`
as your first two stops before touching the server manually.

---

## Symptom: Server health WARNING/CRITICAL

1. Run `bin/server_health.sh` (or check the latest `reports/health_*.txt`).
2. Identify which metric tripped: CPU, memory, swap, disk, load, or zombies.
3. CPU/Load high → `ps aux --sort=-%cpu | head` to find the top consumer.
4. Memory high → `ps aux --sort=-%mem | head`; check for a leak (steadily
   growing RSS over repeated `process_monitor.sh` runs).
5. Disk high → `bin/disk_cleanup.sh --dry-run --path /` to see candidates,
   then `--apply` once reviewed. Also check `du -h --max-depth=2 /` for the
   worst offenders manually.
6. Zombies present → identify the parent PID (`ps -eo pid,ppid,stat,cmd |
   grep ' Z'`) — zombies indicate a parent process not reaping children;
   the parent process itself usually needs a restart or a code fix.
7. Network DOWN → check `ip a`, `ip route`, and whether the outage is
   host-local or upstream (`bin/network_monitor.sh` against a known-good
   external host).

## Symptom: Application process is DOWN

1. `bin/process_monitor.sh <name> --restart --service <service>` — this
   both reports status and attempts a systemd restart.
2. If restart fails repeatedly, check `journalctl -u <service> -n 100` for
   the crash reason.
3. Check `enterprise-app.service`'s `StartLimitBurst`/`StartLimitIntervalSec`
   — systemd will stop attempting restarts after repeated failures within
   the interval; `systemctl reset-failed <service>` before retrying once the
   root cause is fixed.

## Symptom: Elevated errors in application logs

1. `bin/log_analyzer.sh /var/log/application/app.log` for a batch summary.
2. For live triage, run `bin/log_monitor.sh` in the foreground (or check
   whether it's already running under systemd) to see critical lines as
   they happen.
3. HTTP 500s → check `bin/app_health.sh` for API/DB status; a spike in 500s
   is often a downstream dependency (DB, cache, third-party API) failing.
4. Timeouts → check network path and downstream service health, not just
   the local app.
5. Authentication failures → distinguish a genuine credential/config issue
   from a brute-force attempt; cross-reference with
   `bin/security_audit.sh`'s failed-login count.

## Symptom: Backup failures

1. Check the summary printed by `bin/backup.sh` and
   `logs/server-automation.log` for which component failed
   (application/config/logs/database).
2. Common causes: destination disk full (`bin/server_health.sh` disk check),
   permission denied on source directories, DB credentials expired.
3. Re-run `bin/backup.sh` after fixing the root cause — it validates every
   archive (`tar -tzf` / `gzip -t`) so a corrupt backup is caught immediately
   rather than discovered during a restore.
4. Never assume a "successful" run without failures is validated — the
   script's Validation section is what actually confirms archive integrity.

## Symptom: A remote server is unreachable

1. `bin/remote_health_check.sh` marks it `UNREACHABLE` in the consolidated
   report.
2. Rule out a local SSH config/key issue first (test manually: `ssh -v
   user@host`).
3. If manual SSH also fails, escalate to infra/cloud provider for
   host-level investigation (power, network, hypervisor).
4. Once restored, re-run `bin/remote_health_check.sh` to confirm and clear
   the alert.

## Symptom: SSL certificate nearing expiry

1. `bin/network_monitor.sh <host> 443 https://<host>/` reports days
   remaining.
2. Renew via your certificate authority / ACME client, then reload the
   web server / load balancer (do not just replace the file — most servers
   need a reload/restart to pick up a new cert).
3. Re-run the check to confirm the new expiry date is reported.

## Symptom: Security audit reports critical findings

1. Review `reports/security_audit_*.txt` in full (script prints only a
   summary to stdout for brevity).
2. World-writable files → tighten permissions (`chmod o-w <file>`) after
   confirming they don't need to be world-writable (rare).
3. Unexpected SUID/SGID binaries → verify they're expected system binaries;
   unfamiliar ones warrant investigation.
4. `PermitRootLogin yes` / `PasswordAuthentication yes` → harden
   `/etc/ssh/sshd_config` (disable root login, prefer key-based auth), then
   `systemctl reload sshd`.

---

## On strict Bash mode (`set -e` / `set -u` / `set -o pipefail`)

This project's scripts use `set -u` (undefined variable = error) and
`set -o pipefail` (a failed command in a pipeline fails the pipeline)
everywhere. **`set -e` is deliberately not used globally.**

Why `set -e` is risky here: monitoring scripts intentionally run several
independent checks (CPU, memory, disk, network...) and need to evaluate
*all* of them to produce a combined status, even if one check's command
returns non-zero (e.g. `ping` failing when network is down, or `grep -c`
returning 1 when a pattern isn't found). Under `set -e`, the first such
non-zero exit would silently kill the whole script before the remaining
checks run — which is the opposite of what a health check should do.

Where a script *does* need strict-fail behavior for a single critical
operation (e.g. `backup.sh`'s tar/gzip steps), that's handled explicitly
with `if <command>; then ... else ...; fi` and a `trap ... ERR` for
unexpected failures, rather than relying on global `set -e`.

Rule of thumb used throughout this project: use `set -u` and `pipefail`
everywhere (catch real bugs — typos in variable names, silent pipeline
failures), but only use `set -e` (or explicit `if` checks) in scripts whose
job is to perform a single sequential procedure where any failure should
genuinely stop everything (e.g. backups), not in scripts whose job is to
evaluate multiple independent conditions and report on all of them.
