#!/usr/bin/env bash
###############################################################################
# common.sh - Shared utility functions used across scripts
###############################################################################

if [[ -n "${__COMMON_SH_LOADED:-}" ]]; then
    return 0 2>/dev/null || exit 0
fi
__COMMON_SH_LOADED=1

# get_cpu_usage - returns integer percent CPU utilization (100 - idle)
get_cpu_usage() {
    if command -v mpstat >/dev/null 2>&1; then
        mpstat 1 1 2>/dev/null | awk '/Average/ {printf "%.0f", 100 - $NF}'
    else
        # Fallback via /proc/stat sampling (works without mpstat/sysstat)
        # Fields after "cpu": user nice system idle iowait irq softirq steal ...
        local u1 n1 s1 idle1 io1 irq1 sirq1 st1
        local u2 n2 s2 idle2 io2 irq2 sirq2 st2
        read -r _ u1 n1 s1 idle1 io1 irq1 sirq1 st1 _ < /proc/stat
        sleep 1
        read -r _ u2 n2 s2 idle2 io2 irq2 sirq2 st2 _ < /proc/stat

        local total1=$((u1+n1+s1+idle1+io1+irq1+sirq1+st1))
        local total2=$((u2+n2+s2+idle2+io2+irq2+sirq2+st2))
        local totald=$((total2-total1)) idled=$((idle2-idle1))

        if [[ $totald -gt 0 ]]; then
            echo $(( (100*(totald-idled)) / totald ))
        else
            echo 0
        fi
    fi
}

# get_memory_usage - returns integer percent memory utilization
get_memory_usage() {
    free | awk '/Mem:/ {printf "%.0f", ($2-$7)/$2 * 100}'
}

# get_swap_usage - returns integer percent swap utilization (0 if no swap)
get_swap_usage() {
    free | awk '/Swap:/ {
        if ($2 == 0) { print 0 }
        else { printf "%.0f", $3/$2 * 100 }
    }'
}

# get_disk_usage <mount_point> - returns integer percent disk usage
get_disk_usage() {
    local mount="${1:-/}"
    df -P "$mount" | awk 'NR==2 {gsub("%","",$5); print $5}'
}

# get_load_average - returns 1-minute load average
get_load_average() {
    awk '{print $1}' /proc/loadavg 2>/dev/null || uptime | awk -F'load average:' '{print $2}' | awk -F, '{print $1}' | tr -d ' '
}

# get_process_count - total running processes
get_process_count() {
    ps -e --no-headers | wc -l
}

# get_zombie_count - number of zombie processes
get_zombie_count() {
    ps -eo stat --no-headers | grep -c '^Z' || true
}

# get_uptime_human
get_uptime_human() {
    uptime -p 2>/dev/null || awk '{print int($1/86400)" days"}' /proc/uptime
}

# check_network - returns "UP" or "DOWN" based on reachability of a known host
check_network() {
    local target="${1:-8.8.8.8}"
    if ping -c1 -W2 "$target" >/dev/null 2>&1; then
        echo "UP"
    else
        echo "DOWN"
    fi
}

# severity_from_thresholds <value> <warn> <crit> - echoes OK|WARNING|CRITICAL
severity_from_thresholds() {
    local value="$1" warn="$2" crit="$3"
    value="${value%.*}"
    if [[ "$value" -ge "$crit" ]]; then
        echo "CRITICAL"
    elif [[ "$value" -ge "$warn" ]]; then
        echo "WARNING"
    else
        echo "OK"
    fi
}

# worst_status a b c ... - given a list of OK/WARNING/CRITICAL, returns the worst
worst_status() {
    local worst="OK"
    for s in "$@"; do
        if [[ "$s" == "CRITICAL" ]]; then
            echo "CRITICAL"; return
        elif [[ "$s" == "WARNING" ]]; then
            worst="WARNING"
        fi
    done
    echo "$worst"
}

# human_bytes <bytes> - convert bytes to human-readable
human_bytes() {
    numfmt --to=iec-i --suffix=B "$1" 2>/dev/null || echo "${1}B"
}
