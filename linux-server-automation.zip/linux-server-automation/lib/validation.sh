#!/usr/bin/env bash
###############################################################################
# validation.sh - Common validation helpers
###############################################################################

if [[ -n "${__VALIDATION_SH_LOADED:-}" ]]; then
    return 0 2>/dev/null || exit 0
fi
__VALIDATION_SH_LOADED=1

# require_cmd <cmd> - exit if a required binary is missing
require_cmd() {
    local cmd="$1"
    if ! command -v "$cmd" >/dev/null 2>&1; then
        echo "[ERROR] Required command not found: $cmd" >&2
        return 1
    fi
    return 0
}

# is_number <value> - true if value is an integer or decimal
is_number() {
    [[ "$1" =~ ^[0-9]+([.][0-9]+)?$ ]]
}

# require_file <path>
require_file() {
    if [[ ! -f "$1" ]]; then
        echo "[ERROR] Required file not found: $1" >&2
        return 1
    fi
    return 0
}

# require_readable_file <path>
require_readable_file() {
    require_file "$1" || return 1
    if [[ ! -r "$1" ]]; then
        echo "[ERROR] File is not readable: $1" >&2
        return 1
    fi
    return 0
}

# valid_username <username> - POSIX-ish username rules
valid_username() {
    [[ "$1" =~ ^[a-z_][a-z0-9_-]{0,31}$ ]]
}

# valid_port <port>
valid_port() {
    is_number "$1" && [[ "$1" -ge 1 && "$1" -le 65535 ]]
}

# confirm_or_dry_run <description> <dry_run_flag>
# Prints what would happen; caller decides whether to actually run the action.
confirm_or_dry_run() {
    local description="$1"
    local dry_run="${2:-false}"
    if [[ "$dry_run" == "true" ]]; then
        echo "[DRY-RUN] Would: $description"
        return 1
    fi
    return 0
}
