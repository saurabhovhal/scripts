#!/usr/bin/env bash
###############################################################################
# notification.sh - Alert dispatch: log file, email, webhook
# Relies on variables from config/config.conf and functions from logging.sh
###############################################################################

if [[ -n "${__NOTIFICATION_SH_LOADED:-}" ]]; then
    return 0 2>/dev/null || exit 0
fi
__NOTIFICATION_SH_LOADED=1

# send_alert <severity: WARNING|CRITICAL> <subject> <message>
send_alert() {
    local severity="$1"
    local subject="$2"
    local message="$3"

    # 1. Log file (always on if enabled)
    if [[ "${ALERT_LOG_ENABLED:-true}" == "true" ]]; then
        if [[ "$severity" == "CRITICAL" ]]; then
            log_crit "ALERT: $subject :: $message"
        else
            log_warn "ALERT: $subject :: $message"
        fi
    fi

    # 2. Email
    if [[ "${ALERT_EMAIL_ENABLED:-false}" == "true" ]]; then
        if command -v mail >/dev/null 2>&1; then
            echo "$message" | mail -s "[$severity] $subject" "${ALERT_EMAIL_TO}" \
                && log_info "Alert emailed to ${ALERT_EMAIL_TO}" \
                || log_error "Failed to send alert email"
        else
            log_warn "ALERT_EMAIL_ENABLED=true but 'mail' command not found; skipping email"
        fi
    fi

    # 3. Webhook
    if [[ "${ALERT_WEBHOOK_ENABLED:-false}" == "true" ]]; then
        if command -v curl >/dev/null 2>&1; then
            local payload
            payload=$(printf '{"severity":"%s","subject":"%s","message":"%s","host":"%s","timestamp":"%s"}' \
                "$severity" "$subject" "$message" "$(hostname)" "$(date -Iseconds)")
            curl -fsS -X POST -H "Content-Type: application/json" \
                -d "$payload" "${ALERT_WEBHOOK_URL}" >/dev/null 2>&1 \
                && log_info "Alert posted to webhook" \
                || log_error "Failed to POST alert to webhook"
        else
            log_warn "ALERT_WEBHOOK_ENABLED=true but 'curl' not found; skipping webhook"
        fi
    fi
}
