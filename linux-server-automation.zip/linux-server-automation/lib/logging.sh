#!/usr/bin/env bash
###############################################################################
# logging.sh - Centralized logging functions
# Usage: source lib/logging.sh
###############################################################################

# Guard against double-sourcing
if [[ -n "${__LOGGING_SH_LOADED:-}" ]]; then
    return 0 2>/dev/null || exit 0
fi
__LOGGING_SH_LOADED=1

_log_ts() {
    date '+%Y-%m-%d %H:%M:%S'
}

# Ensure log directory exists before first write
_ensure_log_dir() {
    local dir
    dir="$(dirname "${CENTRAL_LOG:-/tmp/server-automation.log}")"
    mkdir -p "$dir" 2>/dev/null || true
}

log_line() {
    local level="$1"; shift
    local msg="$*"
    local line
    line="$(_log_ts) ${level} ${msg}"
    _ensure_log_dir
    echo "$line" | tee -a "${CENTRAL_LOG:-/tmp/server-automation.log}" >/dev/null
}

log_info()  { log_line "INFO " "$*"; echo "[INFO]  $*"; }
log_warn()  { log_line "WARN " "$*"; echo "[WARN]  $*" >&2; }
log_error() { log_line "ERROR" "$*"; echo "[ERROR] $*" >&2; }
log_crit()  { log_line "CRIT " "$*"; echo "[CRIT]  $*" >&2; }
