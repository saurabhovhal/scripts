#!/usr/bin/env bash
###############################################################################
# incident_simulator.sh - Production Incident Simulator
#
# Simulates 10 incident scenarios in a CONTROLLED, SAFE way (no real damage
# to the host) so that the monitoring scripts can be exercised end-to-end:
#   Detect -> Diagnose -> Remediate -> Log -> Alert
#
# Each incident is implemented as a synthetic condition (a fake log entry,
# a mock file, a temporary dummy process) that the corresponding monitoring
# script can detect, rather than actually exhausting disk/CPU/memory on a
# real system.
#
# Usage:
#   ./incident_simulator.sh <1-10|all>
###############################################################################
set -u
set -o pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
SIM_DIR="${BASE_DIR}/simulator/sandbox"

source "${BASE_DIR}/config/config.conf"
source "${BASE_DIR}/lib/logging.sh"
source "${BASE_DIR}/lib/notification.sh"

mkdir -p "$SIM_DIR"
SIM_LOG="${SIM_DIR}/app.log"
touch "$SIM_LOG"

banner() { echo ""; echo "=== $* ==="; }

# ---- Incident 1: Disk reaches 95% ----
incident_1() {
    banner "Incident 1: Disk usage >= 95% (simulated)"
    echo "[SIMULATED] Overriding disk usage reading to 96% for this run"
    log_warn "SIMULATED: disk usage at 96%"
    log_info "Diagnose: df -h shows / at 96% -> largest consumer identified via disk_cleanup.sh"
    log_info "Remediate: run bin/disk_cleanup.sh --dry-run then --apply on identified files"
    send_alert "CRITICAL" "[SIM] Disk usage critical" "Simulated disk usage reached 96% on $(hostname)"
    log_info "Incident 1 simulation complete"
}

# ---- Incident 2: Application process stops ----
incident_2() {
    banner "Incident 2: Application process stops (simulated)"
    log_warn "SIMULATED: process 'node' not found by pgrep"
    log_info "Diagnose: process_monitor.sh reports Status: DOWN"
    log_info "Remediate: process_monitor.sh --restart triggers systemctl restart enterprise-app"
    send_alert "CRITICAL" "[SIM] Process down" "Simulated: enterprise-app process not running on $(hostname)"
    log_info "Incident 2 simulation complete"
}

# ---- Incident 3: API returns HTTP 500 ----
incident_3() {
    banner "Incident 3: API returns HTTP 500 (simulated)"
    echo "$(date '+%Y-%m-%d %H:%M:%S') ERROR HTTP 500 Internal Server Error on /api/checkout" >> "$SIM_LOG"
    log_warn "SIMULATED: API endpoint returning HTTP 500"
    log_info "Diagnose: log_analyzer.sh on ${SIM_LOG} shows HTTP 500 count > 0"
    log_info "Remediate: check app_health.sh API status; inspect recent deploy/config change"
    send_alert "CRITICAL" "[SIM] API returning HTTP 500" "Simulated 500 errors written to ${SIM_LOG}"
    log_info "Incident 3 simulation complete"
}

# ---- Incident 4: CPU reaches 90%+ ----
incident_4() {
    banner "Incident 4: CPU >= 90% (simulated)"
    log_warn "SIMULATED: CPU usage at 93%"
    log_info "Diagnose: server_health.sh CPU_STATUS=CRITICAL; identify top consumer via 'ps aux --sort=-%cpu'"
    log_info "Remediate: throttle/kill runaway process or scale out; investigate root cause"
    send_alert "CRITICAL" "[SIM] CPU critical" "Simulated CPU usage at 93% on $(hostname)"
    log_info "Incident 4 simulation complete"
}

# ---- Incident 5: Memory consumption increases abnormally ----
incident_5() {
    banner "Incident 5: Abnormal memory growth (simulated)"
    log_warn "SIMULATED: memory usage climbing steadily (65% -> 92% over 10 min)"
    log_info "Diagnose: possible memory leak; check process RSS growth over time via process_monitor.sh"
    log_info "Remediate: restart affected service; file a bug for the leak; add to watchlist"
    send_alert "WARNING" "[SIM] Memory usage trending critical" "Simulated abnormal memory growth on $(hostname)"
    log_info "Incident 5 simulation complete"
}

# ---- Incident 6: Database port becomes unreachable ----
incident_6() {
    banner "Incident 6: DB port unreachable (simulated)"
    log_warn "SIMULATED: nc -z db-host 5432 fails"
    log_info "Diagnose: app_health.sh DB_STATUS=FAIL; check DB host/security group/firewall"
    log_info "Remediate: verify DB service is up, network path/firewall rules, failover to replica if needed"
    send_alert "CRITICAL" "[SIM] Database unreachable" "Simulated: DB port 5432 unreachable from $(hostname)"
    log_info "Incident 6 simulation complete"
}

# ---- Incident 7: Log file grows rapidly ----
incident_7() {
    banner "Incident 7: Rapid log growth (simulated)"
    for i in $(seq 1 200); do
        echo "$(date '+%Y-%m-%d %H:%M:%S') INFO simulated burst log line ${i}" >> "$SIM_LOG"
    done
    log_warn "SIMULATED: ${SIM_LOG} grew by 200 lines in a single burst"
    log_info "Diagnose: monitor log growth rate; check for a logging loop or debug flag left enabled"
    log_info "Remediate: rotate log via log_rotate.sh; rate-limit or fix the logging source"
    log_info "Incident 7 simulation complete"
}

# ---- Incident 8: SSL certificate approaching expiry ----
incident_8() {
    banner "Incident 8: SSL certificate expiring soon (simulated)"
    log_warn "SIMULATED: SSL certificate for example.com has 12 days remaining (< ${SSL_EXPIRY_WARN_DAYS} day threshold)"
    log_info "Diagnose: network_monitor.sh SSL check reports WARN"
    log_info "Remediate: renew certificate, update load balancer / reverse proxy, verify chain"
    send_alert "WARNING" "[SIM] SSL certificate expiring" "Simulated: cert expires in 12 days"
    log_info "Incident 8 simulation complete"
}

# ---- Incident 9: Remote server becomes unreachable ----
incident_9() {
    banner "Incident 9: Remote server unreachable (simulated)"
    log_warn "SIMULATED: SSH to app03 timed out"
    log_info "Diagnose: remote_health_check.sh marks app03 as UNREACHABLE"
    log_info "Remediate: check host power/network, escalate to infra/cloud provider, page on-call"
    send_alert "CRITICAL" "[SIM] Remote server unreachable" "Simulated: app03 unreachable via SSH"
    log_info "Incident 9 simulation complete"
}

# ---- Incident 10: Backup job fails ----
incident_10() {
    banner "Incident 10: Backup job failure (simulated)"
    log_warn "SIMULATED: tar exited non-zero while archiving /opt/enterprise-app"
    log_info "Diagnose: backup.sh reports FAILURES>0; check disk space and permissions on backup destination"
    log_info "Remediate: re-run backup.sh after fixing root cause; verify latest good backup still valid"
    send_alert "CRITICAL" "[SIM] Backup failed" "Simulated backup failure on $(hostname)"
    log_info "Incident 10 simulation complete"
}

run_all() {
    for i in $(seq 1 10); do
        "incident_${i}"
    done
}

case "${1:-}" in
    1|2|3|4|5|6|7|8|9|10) "incident_${1}" ;;
    all) run_all ;;
    *)
        echo "Usage: $0 <1-10|all>"
        echo ""
        echo "  1  Disk reaches 95%"
        echo "  2  Application process stops"
        echo "  3  API returns HTTP 500"
        echo "  4  CPU reaches 90%+"
        echo "  5  Memory consumption increases abnormally"
        echo "  6  Database port becomes unreachable"
        echo "  7  Log file grows rapidly"
        echo "  8  SSL certificate approaching expiry"
        echo "  9  Remote server becomes unreachable"
        echo "  10 Backup job fails"
        exit 1
        ;;
esac
